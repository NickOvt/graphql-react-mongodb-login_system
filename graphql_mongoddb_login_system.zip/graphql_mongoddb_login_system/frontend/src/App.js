import React, { useState } from 'react';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';

import AuthPage from './pages/Auth';
import EventsPage from './pages/Events';
import BookingsPage from './pages/Bookings';
import MainNav from './components/Navigation/MainNav';
import AuthContext from './context/auth-context';

import './App.css';

function App() {
    const [state, setNewState] = useState({
        token: null,
        userId: null
    });

    const login = (token, userId, tokenExpiration) => {
        setNewState({ token: token, userId: userId });
    };

    const logout = () => {
        setNewState({ token: null, userId: null });
    };

  return (
    <BrowserRouter>
        <AuthContext.Provider value={{token: state.token, userId: state.userId, login: login, logout: logout}}>
            <MainNav />
            <main className="main-content">
                <Switch>
                    {state.token && <Redirect from="/" to="/events" exact />}
                    {state.token && <Redirect from="/auth" to="/events" exact />}
                    {!state.token && <Route path="/auth" component={AuthPage} />}
                    <Route path="/events" component={EventsPage} />
                    {state.token && <Route path="/bookings" component={BookingsPage} />}
                    {!state.token && <Redirect to="/auth" exact />}
                </Switch>
            </main>
        </AuthContext.Provider>
    </BrowserRouter>
  );
}

export default App;

import React from 'react';

import './Backdrop.css';

function backdrop (props) {
    return (
        <div className="backdrop">

        </div>
    );
}

export default backdrop;

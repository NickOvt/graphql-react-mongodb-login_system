import React, { Fragment } from 'react';
import { NavLink } from 'react-router-dom';

import AuthContext from '../../context/auth-context';
import './MainNav.css';

function mainNav(props) {
    return (
        <AuthContext.Consumer>
            {(context) => {
                return (
                    <header className="main-nav">
                        <div className="main-nav_logo">
                            <h1>Easy Event</h1>
                        </div>
                        <nav className="main-nav_items">
                            <ul>
                                {!context.token &&
                                    <li>
                                        <NavLink to="/auth" >Authenticate</NavLink>
                                    </li>}

                                    <li>
                                        <NavLink to="/events" >Events</NavLink>
                                    </li>

                                {context.token && (
                                    <Fragment>
                                        <li>
                                            <NavLink to="/bookings" >Bookings</NavLink>
                                        </li>
                                        <li>
                                            <button onClick={context.logout}>Logout</button>
                                        </li>
                                    </Fragment>
                                )}
                            </ul>
                        </nav>
                    </header>
                );
            }}
        </AuthContext.Consumer>
    );
}

export default mainNav;

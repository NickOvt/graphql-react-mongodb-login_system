import React from 'react';


function Auth() {
  return (
    <h1>The Bookings Page</h1>
  );
}

export default Auth;

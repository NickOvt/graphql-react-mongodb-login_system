const userResolver = require('./User');
const eventsResolver = require('./Events');
const bookingResolver = require('./Booking');

const rootResolver = {
    ...userResolver,
    ...eventsResolver,
    ...bookingResolver
};

module.exports = rootResolver;

import React from 'react';


function Auth() {
  return (
    <h1>The Events Page</h1>
  );
}

export default Auth;
